module.exports = {
  testEnvironment: 'node',
  collectCoverage: true,
};
