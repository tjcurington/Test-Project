import toggleDocumentValidationAction from '../actions/toggleDocumentValidation';

export default [toggleDocumentValidationAction];
