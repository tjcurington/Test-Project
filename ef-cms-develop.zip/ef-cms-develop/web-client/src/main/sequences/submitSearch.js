import navigateToCaseDetail from '../actions/navigateToCaseDetail';
import formatSearchParams from '../actions/formatSearchParams';

export default [formatSearchParams, navigateToCaseDetail];
