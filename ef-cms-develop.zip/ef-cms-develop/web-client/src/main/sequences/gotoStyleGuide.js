import setCurrentPage from '../actions/setCurrentPage';

export default [setCurrentPage('StyleGuide')];
