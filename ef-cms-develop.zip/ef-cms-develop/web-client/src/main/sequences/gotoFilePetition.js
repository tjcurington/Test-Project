import clearAlerts from '../actions/clearAlerts';
import clearPetition from '../actions/clearPetition';
import setCurrentPage from '../actions/setCurrentPage';

export default [clearAlerts, clearPetition, setCurrentPage('FilePetition')];
