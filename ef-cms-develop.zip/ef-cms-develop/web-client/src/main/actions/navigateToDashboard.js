export default async ({ router }) => {
  await router.route('/');
};
