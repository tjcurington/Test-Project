module.exports = {
  extends: ['stylelint-config-idiomatic-order', 'stylelint-config-recommended'],
};
