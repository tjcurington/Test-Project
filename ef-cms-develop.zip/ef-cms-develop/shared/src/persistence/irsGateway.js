exports.sendToIRS = async () => {
  // noop
  return new Date().toISOString();
};
