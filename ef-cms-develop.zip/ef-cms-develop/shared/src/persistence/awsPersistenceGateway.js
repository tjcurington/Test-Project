/**
 * awsPersistenceGateway
 */
const { uploadPdf } = require('./awsS3Persistence');

module.exports = {
  uploadPdf,
};
