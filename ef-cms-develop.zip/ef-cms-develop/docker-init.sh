#!/bin/bash -e
docker build -t init -f Dockerfile.web-client .