module.exports = {
  arrowParens: 'avoid',
  bracketSpacing: true,
  printWidth: 80,
  semi: true,
  singleQuote: true,
  trailingComma: 'all',
  useTabs: false,
};
