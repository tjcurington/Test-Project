#!/bin/bash -e
docker kill run-all